
Datasets

`rep_height_weights.csv`: heights, weights and self-reported heights and weights for men and women. 
[Source](http://vincentarelbundock.github.io/Rdatasets/csv/car/Davis.csv)
[Documentation](http://vincentarelbundock.github.io/Rdatasets/doc/car/Davis.html)