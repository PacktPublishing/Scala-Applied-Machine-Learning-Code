// Physicist.scala
case class Physicist(
  val name:String,
  val gender:Gender.Value
)
