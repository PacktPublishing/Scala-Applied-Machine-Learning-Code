object Gender extends Enumeration {
  val Male = Value
  val Female = Value
}
