
case class User(login:String, id:Long, repos:List[Repo])
