
object Language extends Enumeration {
  val Scala, Java, JavaScript = Value
}
